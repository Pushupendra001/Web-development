// src/App.js
import React from 'react';
import NotesApp from './components/NotesApp';
import 'bootstrap/dist/css/bootstrap.min.css';
import './styles/App.css';

const App = () => {
  return (
    <div className="App">
      <NotesApp />
    </div>
  );
};

export default App;
