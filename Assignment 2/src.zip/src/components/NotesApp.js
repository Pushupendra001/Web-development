// src/components/NotesApp.js
import React, { useState, useEffect } from 'react';
import Note from './Note';
import NoteForm from './NoteForm';
import DarkModeToggle from './DarkModeToggle';

const NotesApp = () => {
  const [notes, setNotes] = useState([]);

  useEffect(() => {
    const savedNotes = JSON.parse(localStorage.getItem('notes')) || [];
    setNotes(savedNotes);
  }, []);

  useEffect(() => {
    localStorage.setItem('notes', JSON.stringify(notes));
  }, [notes]);

  const addNote = (note) => {
    setNotes([...notes, note]);
  };

  const deleteNote = (id) => {
    setNotes(notes.filter(note => note.id !== id));
  };

  return (
    <div className="container">
      <h1 className="my-4">Notes</h1>
      <DarkModeToggle />
      <NoteForm addNote={addNote} />
      <div className="mt-4">
        {notes.map(note => (
          <Note key={note.id} note={note} onDelete={deleteNote} />
        ))}
      </div>
    </div>
  );
};

export default NotesApp;
