// src/components/DarkModeToggle.js
import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const DarkModeToggle = () => {
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    const currentMode = localStorage.getItem('darkMode') === 'true';
    setDarkMode(currentMode);
    document.body.classList.toggle('bg-dark', currentMode);
    document.body.classList.toggle('text-white', currentMode);
  }, []);

  const toggleDarkMode = () => {
    const newMode = !darkMode;
    setDarkMode(newMode);
    localStorage.setItem('darkMode', newMode);
    document.body.classList.toggle('bg-dark', newMode);
    document.body.classList.toggle('text-white', newMode);
  };

  return (
    <div className="form-check form-switch">
      <input 
        className="form-check-input" 
        type="checkbox" 
        id="darkModeSwitch" 
        checked={darkMode} 
        onChange={toggleDarkMode} 
      />
      <label className="form-check-label" htmlFor="darkModeSwitch">
        {darkMode ? 'Dark Mode' : 'Light Mode'}
      </label>
    </div>
  );
};

export default DarkModeToggle;
